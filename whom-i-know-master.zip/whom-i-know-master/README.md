# whom-i-know
Demo: http://artfultom.github.io/whom-i-know

## Compatibility

IE is your problem.

## Run

```
$ npm start
```

## Build (and test) without run

```
$ gulp
```
